package com.example.examen_app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.examen_app.ui.screens.LoginScreen
import com.example.examen_app.ui.screens.SignupScreen

sealed class Routes(val route: String) {
    object Login : Routes("login")
    object Signup : Routes("signup")
}

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Routes.Login.route) {
        composable(Routes.Login.route) {
            LoginScreen(navController)
        }
        composable(Routes.Signup.route) {
            SignupScreen(navController)
        }
    }
}
